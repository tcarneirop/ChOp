#include <string.h>
#include <mpi.h>

#include <memory>

#ifndef COMMUNICATOR_H
#define COMMUNICATOR_H

// class pbab;
// class fact_work;
class work;
class solution;

class communicator{
public:
    // pbab* pbb;
    communicator(int,pbab*);
    ~communicator();

    void send_work(std::shared_ptr<work> src_wrk, int dest, int tag);
    void recv_work(std::shared_ptr<work> dst_wrk, int src, int tag, MPI_Status* status);

    void send_sol(solution* sol, int dest, int tag);
    void recv_sol(solution* sol, int dest, int tag, MPI_Status* status);
};


#endif
