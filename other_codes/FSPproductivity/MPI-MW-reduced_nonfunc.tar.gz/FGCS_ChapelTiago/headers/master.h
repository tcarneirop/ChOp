#ifndef MASTER_H
#define MASTER_H

class communicator;

class master{
public:
    int nProc;

    communicator* comm;

    master(pbab* _pbb);
    ~master();

    void run();
};

#endif
