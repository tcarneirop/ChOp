#include <atomic>

#ifndef WORKER_H
# define WORKER_H

class pbab;
class communicator;
class matrix_controller;
class fact_work;
class solution;

class gpubb;

class worker {
    // private:
public:
    int M;
    int size;
    char type;

    bool standalone;

    communicator * comm;
    pbab * pbb;

    matrix_controller * mc;
    gpubb * gbb;

//    fact_work * work_buf;
    solution * best_buf;

    worker(pbab * _pbb);
    ~worker();

    int best;

    void tryLaunchCommBest();
    void tryLaunchCommWork();

    void
    updateWorkUnit();
    bool
    doWork();
    void
    getIntervals();

    pthread_barrier_t barrier;
    pthread_mutex_t mutex_end;
    pthread_mutex_t mutex_wunit;
    pthread_mutex_t mutex_best;
    pthread_mutex_t mutex_updateAvail;
    pthread_cond_t cond_updateApplied;

    pthread_mutex_t mutex_trigger;
    pthread_cond_t cond_trigger;

    volatile bool end;
    volatile bool newBest;
    volatile bool trigger;
    volatile bool updateAvailable;
    volatile bool sendRequest;
    volatile bool sendRequestReady;

    bool checkpoint;
    void
    setCheckpoint(bool var);
    bool
    getCheckpoint();

    void
    run();

    void test();
};

#endif // ifndef WORKER_H
