#include <mpi.h>

#include "../headers/master.h"
#include "../headers/communicator.h"

// #include "../headers/works.h"

#include "gmp.h"
#include "gmpxx.h"

#define MAX_INTERVALS 16384 //max buffersize

master::master(pbab* _pbb){
    pbb=_pbb;

    MPI_Comm_size(MPI_COMM_WORLD, &nProc);

    comm = new communicator(MAX_INTERVALS,pbb);
    master_sol = new solution(pbb);
    master_sol->bestcost=arguments::initial_ub;
    // wrks = new works();

    // pbb->sltn->getBestSolution(master_sol);
    // printf("Master - Initial upper bound : %d\n",master_sol->bestcost);fflush(stdout);

    wrk = std::make_shared<work>(pbb);//(new work(pbb));

    end=false;
}

master::~master()
{
    delete comm;
    delete wrks;
    delete master_sol;
//    delete wrk_buf;
//    delete node_count;
}

//main thread of proc 0...
void
master::run()
{
    MPI_Status status;

    do{
        //master busy waiting ...
        MPI_Probe(MPI_ANY_SOURCE,MPI_ANY_TAG,MPI_COMM_WORLD,&status);

        switch (status.MPI_TAG) {
            case WORK:
            {
                comm->recv_work(wrk, status.MPI_SOURCE, WORK, &status);
                /*****
                *
                * handle work ........
                *
                * ****/

                //send appropriate answer
                if(shutdownWorker || end){
                    MPI_Send(&dummy,1,MPI_INT,status.MPI_SOURCE,END,MPI_COMM_WORLD);
                }else if(modified){
                    comm->send_work(wrk,status.MPI_SOURCE, WORK);
                }else{
                    MPI_Send(&master_sol->bestcost,1,MPI_INT,status.MPI_SOURCE,NIL,MPI_COMM_WORLD);
                }
                break;
            }
            case BEST:
            {
                comm->recv_sol(candidate, status.MPI_SOURCE, BEST, &status);
                /*******
                *
                * handle new best sol
                *
                * ****/
                if(end){
                    MPI_Send(&dummy,1,MPI_INT,status.MPI_SOURCE,END,MPI_COMM_WORLD);
                }else{
                    MPI_Send(&master_sol->bestcost,1,MPI_INT,status.MPI_SOURCE,BEST,MPI_COMM_WORLD);
                }
                break;
            }
            case END: /* handle termination.... */
            {
                MPI_Recv(&dummy, 1, MPI_INT, status.MPI_SOURCE, END, MPI_COMM_WORLD, &status);
                count_out++;
                break;
            }
        }
    }while(count_out!=nProc-1);//(!M->end);
}
