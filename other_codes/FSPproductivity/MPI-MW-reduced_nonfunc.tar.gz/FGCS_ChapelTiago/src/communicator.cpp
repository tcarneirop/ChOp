#include "../headers/communicator.h"

communicator::communicator(int _M,pbab* _pbb){
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    /****
    *
    *other
    *
    * ****/

}
//===============================================
communicator::~communicator()
{
    //delete work_buf;
    delete best_buf;
}
/***************************
*
*
*
*
*
* FUNCTIONS BELOW ARE COMPLEX BECAUSE OF GMP INTERVALS !!!
*
*
*
*
* ********************/
void communicator::send_work(std::shared_ptr<work> src_wrk, int dest, int tag)
{
    // printf("send_work\n");fflush(stdout);
    char *buffer=(char*)malloc(MAX_COMM_BUFFER);
    int pos=0;

    src_wrk->nb_intervals=(src_wrk->Uinterval).size();
    MPI_Pack(&src_wrk->id, 1, MPI_INT, buffer, MAX_COMM_BUFFER, &pos, MPI_COMM_WORLD);
    MPI_Pack(&src_wrk->nb_intervals, 1, MPI_INT, buffer, MAX_COMM_BUFFER, &pos, MPI_COMM_WORLD);
    MPI_Pack(&src_wrk->max_intervals, 1, MPI_INT, buffer, MAX_COMM_BUFFER, &pos, MPI_COMM_WORLD);
    MPI_Pack(&src_wrk->exploredNodes, 1, MPI_INT, buffer, MAX_COMM_BUFFER, &pos, MPI_COMM_WORLD);
//    printf("send id %d, nb intervals %d\n",src_wrk->id,src_wrk->nb_intervals);

    char ptr[2000];
    FILE* bp = fmemopen(ptr, 2000, "w");

    size_t sz;

    for (INTERVAL_IT it = (src_wrk->Uinterval).begin(); it != (src_wrk->Uinterval).end(); ++it) {
        MPI_Pack(&(*it)->id, 1, MPI_INT, buffer, MAX_COMM_BUFFER, &pos, MPI_COMM_WORLD);
        MPI_Pack(&(*it)->lb, 1, MPI_INT, buffer, MAX_COMM_BUFFER, &pos, MPI_COMM_WORLD);

        sz=mpz_out_raw(bp, ((*it)->begin).get_mpz_t());

        rewind(bp);
        MPI_Pack(ptr, 100, MPI_BYTE, buffer, MAX_COMM_BUFFER, &pos, MPI_COMM_WORLD);

        sz=mpz_out_raw(bp, ((*it)->end).get_mpz_t());

        rewind(bp);
        MPI_Pack(ptr, 100, MPI_BYTE, buffer, MAX_COMM_BUFFER, &pos, MPI_COMM_WORLD);

    }

    MPI_Send(buffer, pos, MPI_PACKED, dest, tag, MPI_COMM_WORLD);

    fclose(bp);
    free(buffer);
}

void communicator::recv_work(std::shared_ptr<work> dst_wrk, int src, int tag, MPI_Status* status){
    char *rbuffer=(char*)malloc(MAX_COMM_BUFFER);


    int ret=MPI_Recv(rbuffer, MAX_COMM_BUFFER, MPI_PACKED, src, tag, MPI_COMM_WORLD, status);
    if(ret==MPI_ERR_TRUNCATE){
        printf("buffer overflow\n");
    }

    int pos=0;
    MPI_Unpack(rbuffer, MAX_COMM_BUFFER, &pos, &dst_wrk->id, 1, MPI_INT, MPI_COMM_WORLD);
    MPI_Unpack(rbuffer, MAX_COMM_BUFFER, &pos, &dst_wrk->nb_intervals, 1, MPI_INT, MPI_COMM_WORLD);
    MPI_Unpack(rbuffer, MAX_COMM_BUFFER, &pos, &dst_wrk->max_intervals, 1, MPI_INT, MPI_COMM_WORLD);
    MPI_Unpack(rbuffer, MAX_COMM_BUFFER, &pos, &dst_wrk->exploredNodes, 1, MPI_INT, MPI_COMM_WORLD);
//    printf("received work %d, nb intervals %d\n",dst_wrk->id,dst_wrk->nb_intervals);
//    fflush(stdout);

    size_t size=0;
    int id,lb;

    char mpz_raw[2000];
    FILE* fd1 = fmemopen(mpz_raw, 2000, "r");

    mpz_t src_mpz;
    mpz_init(src_mpz);

    mpz_class tmpb(0);
    mpz_class tmpe(0);

    for(int i=0;i<dst_wrk->nb_intervals;i++){
        MPI_Unpack(rbuffer, MAX_COMM_BUFFER, &pos, &id, 1, MPI_INT, MPI_COMM_WORLD);
        MPI_Unpack(rbuffer, MAX_COMM_BUFFER, &pos, &lb, 1, MPI_INT, MPI_COMM_WORLD);

//        std::cout<<pos<<" "<<id<<std::endl;

        rewind(fd1);
        MPI_Unpack(rbuffer, MAX_COMM_BUFFER, &pos, mpz_raw, 100, MPI_BYTE, MPI_COMM_WORLD);

        // pbb->ttm->off(pbb->ttm->masterWalltime);
        size = mpz_inp_raw(src_mpz, fd1);
        tmpb=mpz_class(src_mpz);

        //=============
        rewind(fd1);
        MPI_Unpack(rbuffer, MAX_COMM_BUFFER, &pos, mpz_raw, 100, MPI_BYTE, MPI_COMM_WORLD);
        size = mpz_inp_raw(src_mpz, fd1);
        tmpe=mpz_class(src_mpz);
//        std::cout<<"R "<<id<<"\t"<<lb<<" "<<tmpb<<" "<<tmpe<<"\n";

//        if(tmpb<tmpe)
        (dst_wrk->Uinterval).emplace_back(new interval(tmpb, tmpe, id, lb));
        // pbb->ttm->on(pbb->ttm->masterWalltime);
    }

    fclose(fd1);
    free(rbuffer);
}


void communicator::send_sol(solution* sol, int dest, int tag)
{
    int *buf = new int[sol->size+1];

    buf[0]=sol->bestcost;
    memcpy(&buf[1], sol->bestpermut, sol->size*sizeof(int));

    MPI_Ssend(buf, sol->size+1, MPI_INT, dest, tag, MPI_COMM_WORLD);

    delete[]buf;
}

void communicator::recv_sol(solution* sol, int src, int tag, MPI_Status* status){
    int *buf = new int[sol->size+1];

    MPI_Recv(buf, sol->size+1, MPI_INT, src, tag, MPI_COMM_WORLD, status);

    sol->bestcost=buf[0];
    memcpy(sol->bestpermut, &buf[1], sol->size*sizeof(int));

    delete[]buf;
}
