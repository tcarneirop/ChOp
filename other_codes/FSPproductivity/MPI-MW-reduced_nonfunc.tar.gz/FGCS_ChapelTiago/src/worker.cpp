#include <mpi.h>

#include "../headers/worker.h"
#include "../headers/pbab.h"
#include "../headers/communicator.h"

worker::worker(pbab * _pbb)
{
    // pbb  = _pbb;
    // size = pbb->size;
    //
    // M  = (arguments::nbivms_mc < 1) ? get_nprocs_conf() : arguments::nbivms_mc;

    comm = new communicator(M, pbb);

    // mc = new matrix_controller(pbb, false);
    //
    //
    // //for mpi calls...
    // comm->work_buf->max_intervals = M;
    // comm->work_buf->id = 0;
    //
    // pthread_barrier_init(&barrier, NULL, 2);// sync worker and helper thread
    // pthread_mutexattr_t attr;
    // pthread_mutexattr_init(&attr);
    // pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK);
    //
    // pthread_mutex_init(&mutex_wunit, &attr);
    // pthread_mutex_init(&mutex_best, &attr);
    // pthread_mutex_init(&mutex_end, &attr);
    // pthread_mutex_init(&mutex_updateAvail, &attr);
    // pthread_mutex_init(&mutex_trigger, &attr);
    //
    // pthread_cond_init(&cond_updateApplied, NULL);
    // pthread_cond_init(&cond_trigger, NULL);
    //
    // end     = false;
    // newBest = false;
    //
    // standalone=false;*/
}

/****************************
*
*
*BELOW : inter-node synchronization things .........
*
*
************************/
/*
void
worker::tryLaunchCommBest(){
    if(standalone)return;

    bool isReady=false;
    pthread_mutex_lock_check(&mutex_trigger);
    isReady = sendRequestReady;
    pthread_mutex_unlock(&mutex_trigger);

    if(isReady){
        pthread_mutex_lock_check(&mutex_trigger);
        sendRequestReady=false;
        newBest=true;
        pthread_cond_signal(&cond_trigger);
        pthread_mutex_unlock(&mutex_trigger);
        pbb->sltn->newBest=false;
    }
}

void
worker::tryLaunchCommWork(){
    bool isReady=false;
    pthread_mutex_lock_check(&mutex_trigger);
    isReady = sendRequestReady;
    pthread_mutex_unlock(&mutex_trigger);

    if(isReady){
        pthread_mutex_lock_check(&mutex_wunit);
        getIntervals();//fill buffer (prepare SEND)
//        printf("got %d intervals\n",comm->work_buf->nb_intervals);
        pthread_mutex_unlock(&mutex_wunit);

        pthread_mutex_lock_check(&mutex_trigger);
        sendRequestReady = false;
        sendRequest      = true;//comm thread uses this to distinguish comm tasks (best/checkpoint)
        pthread_cond_signal(&cond_trigger);
        pthread_mutex_unlock(&mutex_trigger);
        trigger = false;// reset...
    }
}
*/


// dedicated thread for ansynchronous communication
void *
comm_thread(void * arg)
{
    //    pthread_t current_thd = pthread_self();
    //    struct sched_param params;
    //    params.sched_priority = sched_get_priority_max(SCHED_FIFO);
    //    pthread_setschedparam(current_thd, SCHED_FIFO, &params);
    //    stick_this_thread_to_core(0);

    worker * w = (worker *) arg;

    // std::shared_ptr<work> wrk(new work(w->pbb));

    MPI_Status status;

    //FLAGS
    // w->sendRequestReady = true;
    // w->sendRequest      = false;
    // w->newBest = false;

    //sync with work-thread
    pthread_barrier_wait(&w->barrier);

    // int nbiter = 0;
    int dummy  = 11;
    // int masterbest;

    while (1) {
        //termination
        bool stop;
        pthread_mutex_lock_check(&w->mutex_end);
        stop = w->end;
        pthread_mutex_unlock(&w->mutex_end);
        if (stop) break;

        // wait unitl update applied (only for ASYNC !!!!!!!)
        bool doCheckpoint;
        bool doBest;
        pthread_mutex_lock_check(&w->mutex_trigger);
        // wait for an event to trigger communication
        while (!w->sendRequest && !w->newBest) {
            pthread_cond_wait(&w->cond_trigger, &w->mutex_trigger);
        }
        doCheckpoint = w->sendRequest;
        doBest       = w->newBest;
        pthread_mutex_unlock(&w->mutex_trigger);

        // nbiter++;
        // checkpoint triggered
        if (doCheckpoint) {
            //reset trigger
            // pthread_mutex_lock_check(&w->mutex_trigger);
            // w->sendRequest = false;
            // pthread_mutex_unlock(&w->mutex_trigger);

            //conmpress data for sending...
           // w->comm->work_buf->fact2dec(w->comm->work_buf, wrk);

           w->comm->send_work(wrk, 0, WORK);
        } else if (doBest)   {
            //reset trigger
            // pthread_mutex_lock_check(&w->mutex_trigger);
            // w->newBest = false;
            // pthread_mutex_unlock(&w->mutex_trigger);

            // get sol
            // w->pbb->sltn->getBestSolution(w->comm->best_buf);// lock on pbb->sltn
            w->comm->send_sol(w->comm->best_buf, 0, BEST);
        }

        //busy waiting for answer !
        MPI_Probe(0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

        // update...
        if (status.MPI_TAG == WORK) {
            std::shared_ptr<work>rwrk(new work(w->pbb));
            w->comm->recv_work(rwrk, 0, MPI_ANY_TAG, &status);
            // w->comm->work_buf->dec2fact(rwrk,w->comm->work_buf);

            // wait unitl update applied (ASYNC)
            // pthread_mutex_lock_check(&w->mutex_updateAvail);
            // w->updateAvailable = true;
            // while (w->updateAvailable) {
            //     pthread_cond_wait(&w->cond_updateApplied, &w->mutex_updateAvail);
            // }
            // pthread_mutex_unlock(&w->mutex_updateAvail);
        } else if (status.MPI_TAG == BEST)   {
            MPI_Recv(&masterbest, 1, MPI_INT, status.MPI_SOURCE, BEST, MPI_COMM_WORLD, &status);
            // w->pbb->sltn->update(w->comm->best_buf->bestpermut, masterbest);
        } else if (status.MPI_TAG == END)   {
            MPI_Recv(&dummy, 1, MPI_INT, 0, END, MPI_COMM_WORLD, &status);
            // w->end = true; //TERMINATION
        } else if (status.MPI_TAG == NIL)   {
            MPI_Recv(&masterbest, 1, MPI_INT, 0, NIL, MPI_COMM_WORLD, &status);
            // w->pbb->sltn->update(w->comm->best_buf->bestpermut, masterbest);
        } else  {
            // printf("unknown message\n"); fflush(stdout); //exception
            // exit(-1);
        }

        // can handle new request now... set flag to true
        // work buffer can be reused!!!
        // if work units were received: the update was taken into account (see cond_updateApplied)
        // else: buffer was used only for send (operation completed)

        // pthread_mutex_lock_check(&w->mutex_trigger); //NEEDED for ASYNC
        // w->sendRequestReady = true;
        // pthread_mutex_unlock(&w->mutex_trigger);
    }

    return NULL;
} // comm_thread

// worker main thread : spawn communicator
void
worker::run()
{
    pthread_t * comm_thd = (pthread_t *) malloc(sizeof(pthread_t));
    pthread_create(comm_thd, &attr, comm_thread, (void *) this);

    trigger = true;// true : got no work
    pthread_barrier_wait(&barrier);// synchronize with communication thread

    int workeriter=0;

    // ==========================================
    // worker main-loop :
    //
    /*
    while (1) {
        trigger = doWork();

        if(pbb->sltn->newBest){
            tryLaunchCommBest();//may be redundant (comm done in doWork)
        }else if(trigger){
            tryLaunchCommWork();
        }
        if(end)break;
    }

    */

    (void) pthread_join(*comm_thd, NULL);

    MPI_Send(&dummy, 1, MPI_INT, 0, END, MPI_COMM_WORLD);

    free(comm_thd);

    return;
} // worker::run
