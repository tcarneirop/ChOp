
/*******
*
*
* ******/


#include <mpi.h>
#include "../headers/worker.h"
#include "../headers/master.h"


int
main(int argc, char ** argv)
{
    int myrank=0;

/*************
*
*
*
**********/

    MPI_Init_thread(&argc, &argv, MPI_THREAD_SERIALIZED, &provided);
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    MPI_Comm_size(MPI_COMM_WORLD, &nProc);
    if (provided != MPI_THREAD_SERIALIZED){
        printf("need MPI_THREAD_SERIALIZED support \n");
        exit(-1);
    }

    //pbb->cutoff=pbb->size;
    if (myrank == 0) {
        pbb->define(new master(pbb));
        // pbb->mstr->initWorks(3);//3 = cut initial interval in nProc pieces
        MPI_Barrier(MPI_COMM_WORLD);
        pbb->mstr->run();
    }
    if (myrank > 0) {
        MPI_Barrier(MPI_COMM_WORLD);
        pbb->define(new worker(pbb));
        pbb->wrkr->run();
    }

/****************
*
*
* ***********/

    MPI_Finalize();

    return 0;// exit(0);
} // main
